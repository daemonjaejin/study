
## Submitting Pull Requests

Before changes can be accepted a Contributor Licensing Agreement for  [Individual](https://docs.google.com/forms/d/1d2R9aVafHTasTYirq-qZx_lx20Obss0ufUS-OtLpu20/viewform) |  [Company](https://docs.google.com/forms/d/1hj5s1bkbmO1OP-UKnSNS6dsDkL1jFDL2XZ5d4IIFdb4/viewform) must be completed. You will be prompted to accept the CLA when you submit your first pull request. If you are Korean, send e-mail to <oss@kakaocorp.com> for agree to the privacy. Then we will send you a CLA copy.
