try {
    EditorJSLoader.readyState = 'loading';
} catch(e) {
}