EditorJSLoader.readyState = "loading";
var Dummy = { };
EditorJSLoader.readyState = "complete";
EditorJSLoader.finish();