/**
 * Created by sungwon on 14. 4. 25.
 */
var testCases = [
    "testcase/robo/tableedit.js"
];